import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

public class ContactServiceTest {
    @Test
    public void testAddContact() {
        ContactService contactService = new ContactService();
        Contact contact = new Contact("C1", "John", "Doe", "1234567890", "123 Main St");
        contactService.addContact(contact);

        assertNotNull(contactService.getContactById("C1"));
    }

}